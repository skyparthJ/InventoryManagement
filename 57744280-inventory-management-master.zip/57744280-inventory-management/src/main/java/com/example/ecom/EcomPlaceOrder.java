package com.example.ecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomPlaceOrder {

    public static void main(String[] args) {
        SpringApplication.run(EcomPlaceOrder.class, args);
    }

}
