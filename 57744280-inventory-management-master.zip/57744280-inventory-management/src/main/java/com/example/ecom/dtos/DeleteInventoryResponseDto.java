package com.example.ecom.dtos;

import lombok.Data;

@Data
public class DeleteInventoryResponseDto {
    private ResponseStatus responseStatus;
}
