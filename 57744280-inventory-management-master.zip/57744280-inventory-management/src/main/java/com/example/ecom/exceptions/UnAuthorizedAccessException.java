package com.example.ecom.exceptions;

public class UnAuthorizedAccessException extends Exception {

    public UnAuthorizedAccessException(String message) {
        super(message);
    }
}
