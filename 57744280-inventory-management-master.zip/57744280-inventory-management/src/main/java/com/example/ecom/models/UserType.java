package com.example.ecom.models;

public enum UserType {
    ADMIN,
    CUSTOMER;
}
