package com.example.ecom.models;


import lombok.Data;

@Data
public abstract class BaseModel {

    private int id;
}
