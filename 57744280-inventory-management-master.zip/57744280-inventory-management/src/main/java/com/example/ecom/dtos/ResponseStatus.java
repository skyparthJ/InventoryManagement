package com.example.ecom.dtos;

public enum ResponseStatus {
    SUCCESS,
    FAILURE
}
